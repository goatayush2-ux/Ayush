package git.artdeell.mojo.game;

import android.view.MotionEvent;
import android.view.View;

import git.artdeell.mojo.Tools;
import git.artdeell.mojo.input.mouse.LeftClickGesture;
import git.artdeell.mojo.input.mouse.Scroller;
import git.artdeell.mojo.input.mouse.TapDetector;
import git.artdeell.mojo.prefs.LauncherPreferences;

import git.artdeell.mojo.CallbackBridge;

public class InGUIEventProcessor extends TouchEventProcessor {
    public static final float FINGER_SCROLL_THRESHOLD = Tools.dpToPx(6);
    public static final float FINGER_STILL_THRESHOLD = Tools.dpToPx(5);
    private final TapDetector mSingleTapDetector;
    private View mTouchpad;
    private boolean mIsMouseDown = false;
    private float mStartX, mStartY;
    private final Scroller mScroller = new Scroller(FINGER_SCROLL_THRESHOLD);

    public InGUIEventProcessor(GameView hostView) {
        super(hostView);
        mSingleTapDetector = new TapDetector(1, TapDetector.DETECTION_METHOD_BOTH);
    }

    @Override
    public boolean processTouchEvent(MotionEvent motionEvent) {
        boolean singleTap = mSingleTapDetector.onTouchEvent(motionEvent);

        switch (motionEvent.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mTracker.startTracking(motionEvent);
                if(!touchpadDisplayed()) {
                    sendTouchCoordinates(motionEvent.getX(), motionEvent.getY());
                    setMoveStart(motionEvent);
                }
                break;

            case MotionEvent.ACTION_MOVE:
                int pointerCount = motionEvent.getPointerCount();
                int pointerIndex = mTracker.trackEvent(motionEvent);
                if(pointerCount == 1 || LauncherPreferences.PREF_DISABLE_GESTURES) {
                    if(touchpadDisplayed()) {
                        applyMoveVector(mTracker.getMotionVector());
                    } else {
                        float mainPointerX = motionEvent.getX(pointerIndex);
                        float mainPointerY = motionEvent.getY(pointerIndex);
                        sendTouchCoordinates(mainPointerX, mainPointerY);

                        if(!mIsMouseDown) {
                            if(LauncherPreferences.PREF_DISABLE_GESTURES) {
                                enableMouse();
                            }else {
                                if(!hasStartedMoving()) setMoveStart(motionEvent);
                                if(!LeftClickGesture.isFingerStill(mStartX, mStartY, mainPointerX, mainPointerY, FINGER_STILL_THRESHOLD))
                                    enableMouse();
                            }
                        }

                    }
                } else mScroller.performScroll(mTracker.getMotionVector());
                break;

            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                mScroller.resetScrollOvershoot();
                mTracker.cancelTracking();

                if(singleTap && !mIsMouseDown) CallbackBridge.performClick(MotionEvent.BUTTON_PRIMARY);

                if(mIsMouseDown) disableMouse();
                resetMove();
        }


        return true;
    }

    private boolean touchpadDisplayed() {
        return mTouchpad != null && mTouchpad.getVisibility() == View.VISIBLE;
    }

    public void setAbstractTouchpad(View touchpad) {
        mTouchpad = touchpad;
    }

    private void enableMouse() {
        CallbackBridge.sendMouseButton(MotionEvent.BUTTON_PRIMARY, true);
        mIsMouseDown = true;
    }

    private void disableMouse() {
        CallbackBridge.sendMouseButton(MotionEvent.BUTTON_PRIMARY, false);
        mIsMouseDown = false;
    }

    private void setMoveStart(MotionEvent event) {
        mStartX = event.getX();
        mStartY = event.getY();
    }

    private void resetMove() {
        mStartX = mStartY = -1;
    }

    private boolean hasStartedMoving() {
        return mStartX != -1 || mStartY != -1;
    }

    @Override
    public void prepareForSwitching() {
        super.prepareForSwitching();
        mScroller.resetScrollOvershoot();
        resetMove();
        if(mIsMouseDown) disableMouse();
    }
}
