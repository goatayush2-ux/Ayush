package git.artdeell.mojo.utils;

import android.util.Log;

import androidx.annotation.Nullable;

import java.io.*;
import java.net.*;
import java.nio.charset.*;


import git.artdeell.mojo.Tools;
import git.artdeell.mojo.downloader.VerificationException;

import org.apache.commons.io.*;

@SuppressWarnings("IOStreamConstructor")
public class DownloadUtils {
    public static final String USER_AGENT = Tools.APP_NAME;

    public static void download(String url, OutputStream os) throws IOException {
        download(new URL(url), os);
    }

    public static void download(URL url, OutputStream os) throws IOException {
        InputStream is = null;
        try {
            // System.out.println("Connecting: " + url.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(10000);
            conn.setDoInput(true);
            conn.connect();
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException("Server returned HTTP " + conn.getResponseCode()
                        + ": " + conn.getResponseMessage());
            }
            is = conn.getInputStream();
            IOUtils.copy(is, os);
        } catch (IOException e) {
            throw new IOException("Unable to download from " + url, e);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static String downloadString(String url) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        download(url, bos);
        bos.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    public static void downloadFile(String url, File out) throws IOException {
        FileUtils.ensureParentDirectory(out);
        try (FileOutputStream fileOutputStream = new FileOutputStream(out)) {
            download(url, fileOutputStream);
        }
    }

    public static void downloadFileMonitored(String urlInput, File outputFile, @Nullable byte[] buffer,
                                             Tools.DownloaderFeedback monitor) throws IOException {
        FileUtils.ensureParentDirectory(outputFile);

        HttpURLConnection conn = (HttpURLConnection) new URL(urlInput).openConnection();
        InputStream readStr = conn.getInputStream();
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            int current;
            int overall = 0;
            int length = conn.getContentLength();

            if (buffer == null) buffer = new byte[65535];

            while ((current = readStr.read(buffer)) != -1) {
                overall += current;
                fos.write(buffer, 0, current);
                monitor.updateProgress(overall, length);
            }
            conn.disconnect();
        }

    }

    public static <T> T downloadStringCached(String url, String cacheName, ParseCallback<T> parseCallback) throws IOException, ParseException{
        File cacheDestination = new File(Tools.DIR_CACHE, "string_cache/"+cacheName);
        if(cacheDestination.isFile() &&
                cacheDestination.canRead() &&
                System.currentTimeMillis() < (cacheDestination.lastModified() + 86400000)) {
            try {
                String cachedString = Tools.read(new FileInputStream(cacheDestination));
                return parseCallback.process(cachedString);
            }catch(IOException e) {
                Log.i("DownloadUtils", "Failed to read the cached file", e);
            }catch (ParseException e) {
                Log.i("DownloadUtils", "Failed to parse the cached file", e);
            }
        }
        String urlContent = DownloadUtils.downloadString(url);
        // if we download the file and fail parsing it, we will yeet outta there
        // and not cache the unparseable sting. We will return this after trying to save the downloaded
        // string into cache
        T parseResult = parseCallback.process(urlContent);

        boolean tryWriteCache;
        if(cacheDestination.exists()) {
            tryWriteCache = cacheDestination.canWrite();
        } else {
            tryWriteCache = FileUtils.ensureParentDirectorySilently(cacheDestination);
        }

        if(tryWriteCache) try {
            Tools.write(cacheDestination, urlContent);
        }catch(IOException e) {
            Log.i("DownloadUtils", "Failed to cache the string", e);
        }
        return parseResult;
    }

    private static boolean verifyFile(File file, String sha1) throws IOException {
        return file.exists() && HashUtils.compareSHA1(file, sha1);
    }

    public static void ensureSha1(File outputFile, @Nullable String sha1, DownloadFunction downloadFunction) throws IOException {
        // Skip if needed
        if(sha1 == null) {
            // If the file exists and we don't know it's SHA1, don't try to redownload it.
            if(outputFile.exists()) return;
            else {
                downloadFunction.download();
                return;
            }
        }

        int attempts = 0;
        boolean fileOkay = verifyFile(outputFile, sha1);
        while (attempts < 5 && !fileOkay){
            attempts++;
            downloadFunction.download();
            fileOkay = verifyFile(outputFile, sha1);
        }
        if(!fileOkay) throw new VerificationException("SHA1 verifcation failed after 5 download attempts");
    }

    /**
     * Get the content length for a given URL.
     * @param url the URL to get the length for
     * @return the length in bytes or -1 if not available
     */
    public static long getContentLength(String url) {
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) new URL(url).openConnection();
            urlConnection.setRequestMethod("HEAD");
            urlConnection.setDoInput(false);
            urlConnection.setDoOutput(false);
            urlConnection.connect();
            int responseCode = urlConnection.getResponseCode();
            if(responseCode >= 200 && responseCode <= 299) return urlConnection.getContentLength();
        }catch (IOException e) {
            Log.w("DownloadUtils", "Failed to get content length", e);
        }
        return -1;
    }

    /**
     * Ping an authlib-injector URL to check if it's available
     * @param url the URL to ping
     * @return whether the ping was successful
     */
    public static boolean pingInjectorUrl(String url) {
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) new URL("https", url, "/").openConnection();
            urlConnection.setRequestMethod("HEAD");
            urlConnection.setConnectTimeout(2000);
            urlConnection.setReadTimeout(500);
            urlConnection.setDoInput(false);
            urlConnection.setDoOutput(false);
            urlConnection.setRequestProperty("User-Agent", "MojoLauncher-Ping/1.0");
            urlConnection.connect();
            int responseCode = urlConnection.getResponseCode();
            if(responseCode != 200) return false;
            if(urlConnection.getHeaderField("x-authlib-injector-api-location") == null) return false;
            return true;
        }catch (IOException e) {
            Log.w("DownloadUtils", "Failed to ping injector url", e);
            return false;
        }
    }

    public interface ParseCallback<T> {
        T process(String input) throws ParseException;
    }

    public interface DownloadFunction {
        void download() throws IOException;
    }

    public static class ParseException extends Exception {
        public ParseException(Exception e) {
            super(e);
        }
    }
}

