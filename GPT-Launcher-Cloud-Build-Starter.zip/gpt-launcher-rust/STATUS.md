# GPT Launcher migration status

## Confirmed inputs
- MojoLauncher source archive: inspected; 875 archive entries.
- Mojo Android app layer: 338 Java files in the supplied source archive.
- Mojo native layer: C/C++-style JNI/CMake code plus external Git submodules.
- Mojo default control layout: imported into `assets/mojo-default-controls.json`.
- Horizon APK: inspected; contains an ARM64 `libhorizon_android.so` with Rust compiler path strings and NativeActivity exports (`android_main`, `ANativeActivity_onCreate`).

## Current Rust work
- `gpt-launcher-core`: Mojo control-layout JSON model, four key slots, round-trip preservation.
- `gpt-launcher-android`: Rust NativeActivity entry-point scaffold.
- `android/`: minimal Gradle Android wrapper and NativeActivity manifest.
- `build-android-arm64.sh`: local ARM64 build recipe using cargo-ndk + Gradle.

## Not yet implemented
- Mojo Java launcher screens and account/session flows.
- Version installation, asset/library resolution, mod-loader installers.
- Runtime/JRE management and native game launch bridge.
- Touch-control rendering/input injection (only the JSON model is implemented).
- Full graphics/audio/input backend and the missing Mojo Git submodules.

## Build status
No APK has been produced. This workspace currently has no Rust compiler, Cargo, Gradle, or Android SDK/NDK installed. The script is provided for a machine with those prerequisites.
