# GPT Launcher — Rust migration scaffold

GPT Launcher is a Rust-first Android rewrite project using **MojoLauncher as the sole product baseline**. Horizon is used only as a technical reference for Rust NativeActivity packaging and ARM64 Android integration; no Horizon UI or launcher behavior is being adopted.

## Current modules
- `crates/mojo-core`: parses and writes Mojo control-layout JSON, preserving unknown fields and normalizing each control to four key slots.
- `crates/android-entry`: Rust `cdylib` NativeActivity entry scaffold for Android.
- `android/`: minimal Android Gradle wrapper and NativeActivity manifest.
- `assets/mojo-default-controls.json`: Mojo's original default control layout.

## ARM64 build
On a development machine with Rust, Android NDK, Android SDK and Gradle installed:

```sh
rustup target add aarch64-linux-android
cargo install cargo-ndk
export ANDROID_HOME=/path/to/Android/Sdk
./build-android-arm64.sh
```

The resulting debug APK path is printed by the script.

## Important
This is an early migration scaffold, **not a feature-complete launcher and not a prebuilt APK**. The full Mojo UI, account flow, version/mod-loader management, Java runtime, graphics/audio/input backends and game-launch bridge remain to be ported. Mojo's source archive also references external Git submodules that are not present in the supplied ZIP. See `STATUS.md` for details.

Mojo-derived work retains its LGPL-3.0-or-later license notice in `MOJO-LICENSE-LGPL-3.0.txt`.
