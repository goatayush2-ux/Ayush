//! Rust migration foundation for GPT Launcher, using MojoLauncher as the sole baseline.
//! This crate deliberately preserves Mojo's JSON control-layout shape before any UI rewrite.

use serde::{Deserialize, Serialize};
use std::{fs, path::Path};
use thiserror::Error;

pub const CONTROL_KEY_SLOTS: usize = 4;
pub const SPECIAL_KEYBOARD: i32 = -1;
pub const SPECIAL_TOGGLE_CONTROLS: i32 = -2;
pub const SPECIAL_MOUSE_PRIMARY: i32 = -3;
pub const SPECIAL_MOUSE_SECONDARY: i32 = -4;
pub const SPECIAL_VIRTUAL_MOUSE: i32 = -5;

#[derive(Debug, Error)]
pub enum LayoutError {
    #[error("could not read control layout: {0}")]
    Io(#[from] std::io::Error),
    #[error("invalid Mojo control layout JSON: {0}")]
    Json(#[from] serde_json::Error),
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct ControlLayout {
    #[serde(default = "default_version")]
    pub version: i32,
    #[serde(default)]
    pub scaled_at: f32,
    #[serde(default, rename = "mControlDataList")]
    pub controls: Vec<Control>,
    #[serde(default, rename = "mDrawerDataList")]
    pub drawers: Vec<Drawer>,
    #[serde(default, rename = "mJoystickDataList")]
    pub joysticks: Vec<Joystick>,
}
fn default_version() -> i32 { -1 }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct Control {
    #[serde(default)] pub name: String,
    #[serde(default)] pub keycodes: Vec<i32>,
    #[serde(default)] pub dynamic_x: String,
    #[serde(default)] pub dynamic_y: String,
    #[serde(default)] pub width: f32,
    #[serde(default)] pub height: f32,
    #[serde(default)] pub is_toggle: bool,
    #[serde(default = "one")] pub opacity: f32,
    #[serde(default)] pub bg_color: i64,
    #[serde(default)] pub stroke_color: i64,
    #[serde(default)] pub stroke_width: f32,
    #[serde(default)] pub corner_radius: f32,
    #[serde(default = "yes")] pub display_in_game: bool,
    #[serde(default = "yes")] pub display_in_menu: bool,
    #[serde(default)] pub is_swipeable: bool,
    #[serde(default)] pub pass_thru_enabled: bool,
    #[serde(default)] pub bitmap_tag: Option<String>,
    /// Keep newer Mojo fields intact during round-trip, even before they are implemented.
    #[serde(flatten)] pub extra: serde_json::Map<String, serde_json::Value>,
}
fn one() -> f32 { 1.0 }
fn yes() -> bool { true }

impl Control {
    /// Mojo pads key arrays to four entries; the Rust model normalizes to the same capacity.
    pub fn four_key_slots(&self) -> [i32; CONTROL_KEY_SLOTS] {
        let mut slots = [0; CONTROL_KEY_SLOTS];
        for (dst, src) in slots.iter_mut().zip(self.keycodes.iter().copied()) { *dst = src; }
        slots
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct Drawer {
    #[serde(default)] pub button_properties: Vec<Control>,
    #[serde(default)] pub properties: Control,
    #[serde(default)] pub orientation: String,
    #[serde(flatten)] pub extra: serde_json::Map<String, serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct Joystick {
    #[serde(flatten)] pub control: Control,
    #[serde(default)] pub forward_lock: bool,
    #[serde(default)] pub absolute: bool,
}

impl ControlLayout {
    pub fn parse_mojo_json(input: &str) -> Result<Self, LayoutError> {
        let mut layout: Self = serde_json::from_str(input)?;
        for control in &mut layout.controls { normalize_keys(control); }
        for drawer in &mut layout.drawers {
            normalize_keys(&mut drawer.properties);
            for control in &mut drawer.button_properties { normalize_keys(control); }
        }
        for joystick in &mut layout.joysticks { normalize_keys(&mut joystick.control); }
        Ok(layout)
    }

    pub fn load(path: impl AsRef<Path>) -> Result<Self, LayoutError> {
        Self::parse_mojo_json(&fs::read_to_string(path)?)
    }

    pub fn to_mojo_json(&self) -> Result<String, LayoutError> {
        Ok(serde_json::to_string_pretty(self)?)
    }

    pub fn total_control_count(&self) -> usize {
        self.controls.len() + self.drawers.iter().map(|d| 1 + d.button_properties.len()).sum::<usize>() + self.joysticks.len()
    }
}

fn normalize_keys(control: &mut Control) {
    control.keycodes.truncate(CONTROL_KEY_SLOTS);
    control.keycodes.resize(CONTROL_KEY_SLOTS, 0);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mojo_default_layout_parses_and_keeps_four_key_slots() {
        let raw = include_str!("../../../assets/mojo-default-controls.json");
        let layout = ControlLayout::parse_mojo_json(raw).expect("Mojo default layout should parse");
        assert!(!layout.controls.is_empty());
        assert_eq!(layout.controls[0].name, "Keyboard");
        assert_eq!(layout.controls[0].four_key_slots(), [SPECIAL_KEYBOARD, 0, 0, 0]);
        assert!(layout.controls.iter().all(|c| c.keycodes.len() == CONTROL_KEY_SLOTS));
    }

    #[test]
    fn round_trip_preserves_mojo_field_names_and_extra_fields() {
        let raw = include_str!("../../../assets/mojo-default-controls.json");
        let layout = ControlLayout::parse_mojo_json(raw).unwrap();
        let output = layout.to_mojo_json().unwrap();
        assert!(output.contains("mControlDataList"));
        assert!(output.contains("dynamicX"));
        let reparsed = ControlLayout::parse_mojo_json(&output).unwrap();
        assert_eq!(layout, reparsed);
    }
}
