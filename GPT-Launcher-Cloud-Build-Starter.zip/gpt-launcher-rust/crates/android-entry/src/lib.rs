//! Android NativeActivity entry point for GPT Launcher.
//!
//! This is the Android packaging/entry scaffold, not the completed launcher UI or
//! Minecraft runtime. Mojo's Java and native subsystems still need to be ported.

use android_activity::AndroidApp;
use android_logger::Config;
use log::LevelFilter;

#[no_mangle]
pub fn android_main(_app: AndroidApp) {
    android_logger::init_once(
        Config::default().with_max_level(LevelFilter::Info),
    );
    log::info!("GPT Launcher native ARM64 entry started");
    // TODO: initialize Rust launcher services, restore app state, create UI,
    // and connect the migrated Mojo game/runtime bridge.
}
