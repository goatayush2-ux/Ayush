#!/usr/bin/env bash
set -euo pipefail

# Run from the project root on a machine with Rust, Android NDK, SDK and Gradle.
command -v cargo-ndk >/dev/null || { echo 'Install cargo-ndk first'; exit 1; }
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK}"

cargo ndk -t arm64-v8a -o android/app/src/main/jniLibs build --release -p gpt-launcher-android
cd android
gradle :app:assembleDebug
printf '\nAPK: %s/android/app/build/outputs/apk/debug/app-debug.apk\n' "$PWD"
