# Cloud build (GitHub Actions)

The workflow at `.github/workflows/android-arm64.yml` builds the current Rust Android **scaffold** for `arm64-v8a` and uploads a debug APK as a GitHub Actions artifact.

## Run it
1. Put this project in a GitHub repository.
2. Open **Actions** → **GPT Launcher Android ARM64**.
3. Choose **Run workflow** (or push to `main`).
4. Open the completed run and download `GPT-Launcher-ARM64-debug` under Artifacts.

## Scope warning
This workflow currently builds the NativeActivity/Rust scaffold only. It does **not** mean the Mojo Java launcher, account flow, version/mod-loader installation, JRE management, Holy GL4ES renderer bridge, or Minecraft game launch path has been ported. Those are still migration work. Do not distribute this scaffold APK as a finished launcher.
